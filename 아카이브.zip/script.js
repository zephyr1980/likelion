/* ════════════════════════════════════════════
   1. CONFIG — 모든 정적 데이터
════════════════════════════════════════════ */
const CONFIG = {
  AB: [
  {
    "dim": "crowd",
    "q": "어디에 더 끌리시나요?",
    "a": {
      "emoji": "🏮",
      "title": "활기 넘치는 야시장",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/night_market,street_food,travel?random=2340"
    },
    "b": {
      "emoji": "🌫️",
      "title": "텅 빈 새벽 골목",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/empty_street,alley_night,travel?random=9054"
    }
  },
  {
    "dim": "local",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "📸",
      "title": "유명 랜드마크 인증샷",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/landmark,statue,monument,travel?random=5469"
    },
    "b": {
      "emoji": "🚶",
      "title": "아무도 모르는 골목 산책",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/walking_alley,hidden_street,travel?random=7954"
    }
  },
  {
    "dim": "pace",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🍽️",
      "title": "미슐랭 3스타 레스토랑",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/finedining,michelin,travel?random=2157"
    },
    "b": {
      "emoji": "🍜",
      "title": "현지인 북적이는 낡은 식당",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/local_restaurant,ramen,noodle,travel?random=9307"
    }
  },
  {
    "dim": "accommodation",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "⏰",
      "title": "아침 8시부터 꽉 찬 일정",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/busy_schedule,running,tourist,travel?random=8187"
    },
    "b": {
      "emoji": "🛌",
      "title": "오후 2시까지 늦잠",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/lazy_sleep,bed_afternoon,travel?random=9156"
    }
  },
  {
    "dim": "culture",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🍻",
      "title": "현지인과 맥주 마시며 수다",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/beer,pub,chatting,travel?random=653"
    },
    "b": {
      "emoji": "🎧",
      "title": "조용히 이어폰 꽂고 걷기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/earphones,walking_alone,travel?random=8992"
    }
  },
  {
    "dim": "night",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🏨",
      "title": "5성급 럭셔리 호텔",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/luxury_hotel,resort,travel?random=310"
    },
    "b": {
      "emoji": "🏡",
      "title": "현지 감성 가득한 에어비앤비",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/airbnb_interior,house,travel?random=1062"
    }
  },
  {
    "dim": "local_life",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🖼️",
      "title": "유명 미술관 도슨트 투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/art_museum,painting,travel?random=2718"
    },
    "b": {
      "emoji": "🛒",
      "title": "동네 슈퍼마켓 장보기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/supermarket,grocery,travel?random=7708"
    }
  },
  {
    "dim": "food_risk",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🌃",
      "title": "화려한 네온사인 야경",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/neon_city_night,cyberpunk,travel?random=6642"
    },
    "b": {
      "emoji": "🌌",
      "title": "별빛 쏟아지는 사막",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/desert_stars,milkyway,travel?random=7356"
    }
  },
  {
    "dim": "discovery",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "📝",
      "title": "철저한 맛집 사전 조사",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/travel_planning,notes,travel?random=8697"
    },
    "b": {
      "emoji": "🚪",
      "title": "길 가다 느낌 있는 곳 직진",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/random_door,street,travel?random=2020"
    }
  },
  {
    "dim": "morning",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🍸",
      "title": "루프탑 바에서 칵테일",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/rooftop_bar,cocktail,travel?random=4225"
    },
    "b": {
      "emoji": "🍜",
      "title": "숙소에서 컵라면과 맥주",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/ramen_cup,hotel_bed,travel?random=9716"
    }
  },
  {
    "dim": "nature",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🚌",
      "title": "관광 명소 투어 버스",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/tour_bus,city_tour,travel?random=1772"
    },
    "b": {
      "emoji": "🚏",
      "title": "현지 시내버스 멍때리기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/local_bus_window,staring,travel?random=456"
    }
  },
  {
    "dim": "social",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🪂",
      "title": "액티비티 (스쿠버, 패러글라이딩)",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/skydiving,paragliding,travel?random=1108"
    },
    "b": {
      "emoji": "☕",
      "title": "경치 보며 여유로운 티타임",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/relax_tea,cafe_view,travel?random=7127"
    }
  },
  {
    "dim": "crowd",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🏛️",
      "title": "역사적인 유적지 탐방",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/ancient_ruins,history,travel?random=3198"
    },
    "b": {
      "emoji": "🛍️",
      "title": "최신 팝업 스토어 투어",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/popup_store,modern_retail,travel?random=7565"
    }
  },
  {
    "dim": "local",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🚗",
      "title": "렌터카로 자유롭게 드라이브",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/driving,road_trip,travel?random=9572"
    },
    "b": {
      "emoji": "🚆",
      "title": "기차 창밖 풍경 감상",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/train_window_view,railway,travel?random=5282"
    }
  },
  {
    "dim": "pace",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🗣️",
      "title": "현지어 한마디라도 써보기",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/talking,language,foreigner,travel?random=8557"
    },
    "b": {
      "emoji": "📱",
      "title": "번역기 앱으로 정확히 소통",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/translator_app,smartphone,travel?random=2463"
    }
  },
  {
    "dim": "accommodation",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🔭",
      "title": "유명 전망대에서 시내 조망",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/observatory_view,city_panorama,travel?random=4015"
    },
    "b": {
      "emoji": "👀",
      "title": "골목길 카페에서 사람 구경",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/cafe_people_watching,travel?random=248"
    }
  },
  {
    "dim": "culture",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🏛️",
      "title": "비 오는 날 미술관 투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/rain_museum,art,travel?random=866"
    },
    "b": {
      "emoji": "☔",
      "title": "비슷한 날 우비 입고 산책",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/walking_rain_poncho,travel?random=6611"
    }
  },
  {
    "dim": "night",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🎒",
      "title": "배낭 하나 메고 훌쩍 떠나기",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/backpack_travel,hiking,travel?random=3176"
    },
    "b": {
      "emoji": "🧳",
      "title": "캐리어 꽉 채워 철저히 준비",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/packing_suitcase,luggage,travel?random=351"
    }
  },
  {
    "dim": "local_life",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🍳",
      "title": "전통 요리 쿠킹 클래스",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/cooking_class,traditional_food,travel?random=7642"
    },
    "b": {
      "emoji": "🌮",
      "title": "푸드트럭 길거리 감성",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/food_truck,taco,street,travel?random=6477"
    }
  },
  {
    "dim": "food_risk",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "📱",
      "title": "SNS 핫플에서 예쁜 사진",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/instagram_photo,influencer,travel?random=6283"
    },
    "b": {
      "emoji": "😌",
      "title": "카메라 내려놓고 눈으로 담기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/enjoying_view_no_camera,travel?random=4501"
    }
  },
  {
    "dim": "discovery",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🧳",
      "title": "매일 숙소 바꾸며 이동",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/moving_hotel,traveling,travel?random=7480"
    },
    "b": {
      "emoji": "🏠",
      "title": "한 숙소에 머물며 딥 다이브",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/cozy_stay,deep_dive,travel?random=3918"
    }
  },
  {
    "dim": "morning",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🌲",
      "title": "숲 피톤치드 맡으며 트레킹",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/forest_trekking,trees,travel?random=7905"
    },
    "b": {
      "emoji": "🏖️",
      "title": "프라이빗 해변에서 태닝",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/private_beach,tanning,travel?random=7170"
    }
  },
  {
    "dim": "nature",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🚩",
      "title": "가이드와 함께하는 워킹투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/guided_walking_tour,travel?random=882"
    },
    "b": {
      "emoji": "🎧",
      "title": "오디오 가이드 꽂고 혼자",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/audio_guide,solo_tour,travel?random=6408"
    }
  },
  {
    "dim": "social",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "⛪",
      "title": "마제스틱한 대성당의 웅장함",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/majestic_cathedral,church,travel?random=7916"
    },
    "b": {
      "emoji": "🕯️",
      "title": "소박한 수도원의 정적",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/quiet_monastery,candle,travel?random=7029"
    }
  },
  {
    "dim": "crowd",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🍷",
      "title": "지역 특산물 와이너리 방문",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/winery,vineyard,wine,travel?random=418"
    },
    "b": {
      "emoji": "🍺",
      "title": "힙한 로컬 브루어리",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/craft_beer,brewery,travel?random=6842"
    }
  },
  {
    "dim": "local",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🏮",
      "title": "활기 넘치는 야시장",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/night_market_lively,travel?random=4476"
    },
    "b": {
      "emoji": "🌫️",
      "title": "텅 빈 새벽 골목",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/foggy_dawn_street,travel?random=793"
    }
  },
  {
    "dim": "pace",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "📸",
      "title": "유명 랜드마크 인증샷",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/landmark_photo,selfie,travel?random=67"
    },
    "b": {
      "emoji": "🚶",
      "title": "아무도 모르는 골목 산책",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/secret_alley_walkway,travel?random=7478"
    }
  },
  {
    "dim": "accommodation",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🍽️",
      "title": "미슐랭 3스타 레스토랑",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/michelin_dinner,fancy,travel?random=1874"
    },
    "b": {
      "emoji": "🍜",
      "title": "현지인 북적이는 낡은 식당",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/noisy_local_diner,travel?random=8166"
    }
  },
  {
    "dim": "culture",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "⏰",
      "title": "아침 8시부터 꽉 찬 일정",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/intense_travel_schedule,travel?random=6789"
    },
    "b": {
      "emoji": "🛌",
      "title": "오후 2시까지 늦잠",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/sleeping_in_afternoon,travel?random=6333"
    }
  },
  {
    "dim": "night",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🍻",
      "title": "현지인과 맥주 마시며 수다",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/pub_conversation,beer,travel?random=8062"
    },
    "b": {
      "emoji": "🎧",
      "title": "조용히 이어폰 꽂고 걷기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/headphones_listening_alone,travel?random=8846"
    }
  },
  {
    "dim": "local_life",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🏨",
      "title": "5성급 럭셔리 호텔",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/luxury_5star_hotel,travel?random=1211"
    },
    "b": {
      "emoji": "🏡",
      "title": "현지 감성 가득한 에어비앤비",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/cozy_airbnb_stay,travel?random=9889"
    }
  },
  {
    "dim": "food_risk",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🖼️",
      "title": "유명 미술관 도슨트 투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/art_gallery_tour,travel?random=656"
    },
    "b": {
      "emoji": "🛒",
      "title": "동네 슈퍼마켓 장보기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/local_grocery_shopping,travel?random=4662"
    }
  },
  {
    "dim": "discovery",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🌃",
      "title": "화려한 네온사인 야경",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/neon_night_cityscape,travel?random=5625"
    },
    "b": {
      "emoji": "🌌",
      "title": "별빛 쏟아지는 사막",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/starlit_desert_sky,travel?random=5954"
    }
  },
  {
    "dim": "morning",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "📝",
      "title": "철저한 맛집 사전 조사",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/careful_planning,diary,travel?random=5815"
    },
    "b": {
      "emoji": "🚪",
      "title": "길 가다 느낌 있는 곳 직진",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/spontaneous_travel,travel?random=2260"
    }
  },
  {
    "dim": "nature",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🍸",
      "title": "루프탑 바에서 칵테일",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/rooftop_cocktail_night,travel?random=4234"
    },
    "b": {
      "emoji": "🍜",
      "title": "숙소에서 컵라면과 맥주",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/hotel_room_snack,travel?random=9480"
    }
  },
  {
    "dim": "social",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🚌",
      "title": "관광 명소 투어 버스",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/tourist_bus_ride,travel?random=9009"
    },
    "b": {
      "emoji": "🚏",
      "title": "현지 시내버스 멍때리기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/local_bus_transport,travel?random=1286"
    }
  },
  {
    "dim": "crowd",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🪂",
      "title": "액티비티 (스쿠버, 패러글라이딩)",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/extreme_sports,skydiving,travel?random=3024"
    },
    "b": {
      "emoji": "☕",
      "title": "경치 보며 여유로운 티타임",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/peaceful_teatime,travel?random=6751"
    }
  },
  {
    "dim": "local",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🏛️",
      "title": "역사적인 유적지 탐방",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/historic_site_ruins,travel?random=1437"
    },
    "b": {
      "emoji": "🛍️",
      "title": "최신 팝업 스토어 투어",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/trendy_popup_shop,travel?random=8778"
    }
  },
  {
    "dim": "pace",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🚗",
      "title": "렌터카로 자유롭게 드라이브",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/roadtrip_driving_car,travel?random=1317"
    },
    "b": {
      "emoji": "🚆",
      "title": "기차 창밖 풍경 감상",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/train_journey_view,travel?random=7167"
    }
  },
  {
    "dim": "accommodation",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🗣️",
      "title": "현지어 한마디라도 써보기",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/speaking_foreign_language,travel?random=6797"
    },
    "b": {
      "emoji": "📱",
      "title": "번역기 앱으로 정확히 소통",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/translation_app_use,travel?random=6243"
    }
  },
  {
    "dim": "culture",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "🔭",
      "title": "유명 전망대에서 시내 조망",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/city_observatory_view,travel?random=2296"
    },
    "b": {
      "emoji": "👀",
      "title": "골목길 카페에서 사람 구경",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/cafe_window_seat,travel?random=7429"
    }
  },
  {
    "dim": "night",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🏛️",
      "title": "비 오는 날 미술관 투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/museum_on_rainy_day,travel?random=1663"
    },
    "b": {
      "emoji": "☔",
      "title": "비슷한 날 우비 입고 산책",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/walking_in_rain,travel?random=6378"
    }
  },
  {
    "dim": "local_life",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🎒",
      "title": "배낭 하나 메고 훌쩍 떠나기",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/backpacking_trip,travel?random=1755"
    },
    "b": {
      "emoji": "🧳",
      "title": "캐리어 꽉 채워 철저히 준비",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/heavy_suitcase_packing,travel?random=8585"
    }
  },
  {
    "dim": "food_risk",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🍳",
      "title": "전통 요리 쿠킹 클래스",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/cooking_class_kitchen,travel?random=2538"
    },
    "b": {
      "emoji": "🌮",
      "title": "푸드트럭 길거리 감성",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/food_truck_street,travel?random=2029"
    }
  },
  {
    "dim": "discovery",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "📱",
      "title": "SNS 핫플에서 예쁜 사진",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/taking_photos,sns,travel?random=2631"
    },
    "b": {
      "emoji": "😌",
      "title": "카메라 내려놓고 눈으로 담기",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/staring_at_scenery,travel?random=639"
    }
  },
  {
    "dim": "morning",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🧳",
      "title": "매일 숙소 바꾸며 이동",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/nomad_traveling,travel?random=32"
    },
    "b": {
      "emoji": "🏠",
      "title": "한 숙소에 머물며 딥 다이브",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/long_stay_vacation,travel?random=6075"
    }
  },
  {
    "dim": "nature",
    "q": "여행지에서의 하루, 어떻게 보낼까요?",
    "a": {
      "emoji": "🌲",
      "title": "숲 피톤치드 맡으며 트레킹",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/forest_hiking_trail,travel?random=985"
    },
    "b": {
      "emoji": "🏖️",
      "title": "프라이빗 해변에서 태닝",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#B47A7A",
      "bgUrl": "https://loremflickr.com/600/800/sunbathing_beach,travel?random=8487"
    }
  },
  {
    "dim": "social",
    "q": "이번 여행에서 피할 수 없는 선택은?",
    "a": {
      "emoji": "🚩",
      "title": "가이드와 함께하는 워킹투어",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/group_walking_tour,travel?random=9543"
    },
    "b": {
      "emoji": "🎧",
      "title": "오디오 가이드 꽂고 혼자",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#9A7AB4",
      "bgUrl": "https://loremflickr.com/600/800/solo_audio_tour,travel?random=6500"
    }
  },
  {
    "dim": "crowd",
    "q": "둘 중 하나만 선택한다면?",
    "a": {
      "emoji": "⛪",
      "title": "마제스틱한 대성당의 웅장함",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4704B",
      "bgUrl": "https://loremflickr.com/600/800/grand_cathedral_interior,travel?random=7676"
    },
    "b": {
      "emoji": "🕯️",
      "title": "소박한 수도원의 정적",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#6B8BA4",
      "bgUrl": "https://loremflickr.com/600/800/quiet_monastery_prayer,travel?random=2503"
    }
  },
  {
    "dim": "local",
    "q": "당신의 심장을 뛰게 하는 것은?",
    "a": {
      "emoji": "🍷",
      "title": "지역 특산물 와이너리 방문",
      "desc": "이끌리는 대로 첫 번째 선택.",
      "c": "#C4A84B",
      "bgUrl": "https://loremflickr.com/600/800/wine_tasting_cellar,travel?random=8651"
    },
    "b": {
      "emoji": "🍺",
      "title": "힙한 로컬 브루어리",
      "desc": "마음이 가는 두 번째 선택.",
      "c": "#7A9A7E",
      "bgUrl": "https://loremflickr.com/600/800/brewery_pub_beer,travel?random=5997"
    }
  }
],

  CORE_DIMENSIONS: ['crowd','local','pace','accommodation','culture','night','local_life'],

  EMOTIONS: ['해방감','경이','안도','호기심','고요','설렘','향수','자유','충만','고독'],

  NEGATIVES: [
    {i:'👥',t:'붐비는 관광지'},{i:'🗣️',t:'과도한 호객행위'},{i:'⚠️',t:'치안 불안 / 소매치기'},
    {i:'😊',t:'지나치게 과한 친절'},{i:'🗑️',t:'지저분한 거리'},{i:'📅',t:'자유 없는 단체 일정'},
    {i:'💰',t:'바가지 요금'},{i:'🔊',t:'밤새 시끄러운 숙소'},{i:'🚌',t:'긴 이동 시간'},
    {i:'📸',t:'사진 찍기 강요'},{i:'🍔',t:'현지 음식 없이 패스트푸드만'},{i:'🏢',t:'개성 없는 체인 호텔'},
    {i:'☔',t:'날씨 때문에 실내만'},{i:'📵',t:'인터넷이 안 되는 곳'},
    {i:'🚫',t:'언어가 전혀 안 통함'},{i:'🧳',t:'짐 끌고 많이 걷기'}
  ],

  ACC_CHIPS: {
    purity: [{t:'냄새 없는 화장실'},{t:'건식 화장실'},{t:'분리형 화장실/샤워'},{t:'매일 시트 교체'},{t:'살균 소독 인증'}],
    comfort: [{t:'프리미엄 침구 (100수+)'},{t:'무풍 에어컨'},{t:'방음 완벽'},{t:'암막 커튼'},{t:'온수 즉시 나옴'}],
    sensory: [{t:'이솝/르라보 어메니티'},{t:'디자인 가구/인테리어'},{t:'뷰 (야경/바다)'},{t:'블루투스 스피커'},{t:'네스프레소 머신'}]
  },

  LOADING_INSIGHTS: [
    {cond: s => s.crowd==='b' && s.local==='b', msg:'고요함을 찾으면서도 현지 골목에 끌린다는 건, 혼자 발견하는 조용한 나만의 장소를 원한다는 뜻이에요.'},
    {cond: s => s.pace==='b'  && s.night==='b', msg:'느린 하루와 호텔 TV 조합 — 여행을 "쉬는 것"으로 정의하는 분이네요.'},
    {cond: s => s.local==='b' && s.culture==='b', msg:'골목 빵집과 슈퍼마켓 탐방 동시 선택 — 소비보다 관찰에서 즐거움을 찾는 타입입니다.'},
    {cond: () => true, msg:'선택 패턴을 분석하고 있습니다. 직감적인 선택이 가장 정확한 취향 지도를 그립니다.'}
  ],

  CITY_DATA: {}, // Fetched via assets/cities
  CITIES: ["파리","런던","뉴욕","로마","바르셀로나","도쿄","방콕","시드니","프라하","부다페스트","비엔나","베를린","암스테르담","리스본","타이베이","오사카","삿포로","싱가포르","홍콩","다낭","코타키나발루","발리","치앙마이","상하이","이스탄불","두바이","시애틀","샌프란시스코","하와이","모로코"],

  COMPANION_LABELS: {solo:'혼자',couple:'커플/친구',family:'가족(어린이 포함)',group:'그룹(3인+)'},
  COMPANION_SHORT:  {solo:'혼자 여행',couple:'커플/친구',family:'가족 여행',group:'그룹 여행'},
  ACC_PRIM_LABELS:  {purity:'위생 우선',comfort:'숙면 우선',sensory:'감각 우선'},
  CAT_NAMES:        {purity:'위생 · 청결',comfort:'숙면 · 편안함',sensory:'감각 · 프리미엄'},
  MONTH_NAMES: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
  TAG_STYLES: {'혼잡도 낮음':'low-crowd','조용한':'low-crowd','한산':'low-crowd','로컬 추천':'local','현지인 추천':'local','숨겨진':'local','기피 요소 없음':'no-avoid','안전':'no-avoid','아침 추천':'timing','저녁 추천':'timing','최적 시간':'timing'}
};

/* ════════════════════════════════════════════
   2. APPLICATION STATE
════════════════════════════════════════════ */
const AppState = {
  round: 0,
  abSubset: [],
  choices: {},
  memoryText: '',
  selectedEmotions: [],
  selectedNegatives: [],
  companion: '',
  accOrder: [],
  selectedAccChips: [],
  currentProfile: null,
  // calendar
  calYear: null, calMonth: null, calSelected: null,
  selectedCity: '',

  reset() {
    this.round=0; this.abSubset=[]; this.choices={};
    this.memoryText=''; this.selectedEmotions=[];
    this.selectedNegatives=[]; this.companion='';
    this.accOrder=[]; this.selectedAccChips=[];
    this.currentProfile=null;
    this.calSelected=null; this.selectedCity='';
    this.cityData = null;
  },

  resetFromNeg() {
    this.selectedNegatives=[]; this.accOrder=[]; this.selectedAccChips=[];
  }
};

/* ════════════════════════════════════════════
   3. UI COMPONENTS — 재사용 가능한 HTML 조각
════════════════════════════════════════════ */
const UI = {
  badge: (text, type) => `<span class="ctx-badge ${type}">${text}</span>`,

  ctxStrip: (profile, companion, accPrim, negCount) => {
    const compLabel = CONFIG.COMPANION_SHORT[companion] || '';
    const accLabel  = CONFIG.ACC_PRIM_LABELS[accPrim] || '';
    return [
      profile?.typeName ? UI.badge(`✦ ${profile.typeName}`, 'dna') : '',
      negCount          ? UI.badge(`✕ ${negCount}가지 기피 반영`, 'avoid') : '',
      accLabel          ? UI.badge(`🏨 ${accLabel}`, 'acc') : '',
      compLabel         ? UI.badge(`👤 ${compLabel}`, 'comp') : ''
    ].join('');
  },

  spotBadges: tags => {
    if (!tags?.length) return '';
    return `<div class="spot-badges">${tags.map(t => {
      const cls = Object.entries(CONFIG.TAG_STYLES).find(([k]) => t.includes(k))?.[1] || 'local';
      return `<span class="spot-badge ${cls}">${t}</span>`;
    }).join('')}</div>`;
  },

  spotItem: spot => `
    <div class="itin-spot">
      <span class="itin-spot-time">${spot.time}</span>
      <div class="itin-spot-body">
        <div class="itin-spot-name">${spot.name}</div>
        <div class="itin-spot-note">${spot.note || ''}</div>
        ${spot.sense ? `<div class="itin-spot-sense">"${spot.sense}"</div>` : ''}
        ${UI.spotBadges(spot.tags)}
      </div>
    </div>`,

  daySection: day => {
    const dayCost = (day.spots || []).reduce((a, s) => a + (s.cost || 0), 0);
    return `
    <div class="itin-day">
      <div class="itin-marker"></div>
      <div class="itin-day-head">
        <span class="itin-day-num">Day ${day.day}</span>
        <span class="itin-day-title">${day.title}</span>
      </div>
      ${dayCost > 0 ? `<div class="itin-day-budget">예상 ${dayCost.toLocaleString()}원</div>` : ''}
      <div class="itin-day-desc">${day.desc || ''}</div>
      ${(day.spots || []).map(UI.spotItem).join('')}
    </div>`;
  },

  minimap: (mapData, cityKey) => {
    if (!mapData) return `
      <div class="minimap-placeholder">
        <div style="font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:2px;color:var(--terra-light);margin-bottom:.5rem;text-transform:uppercase">리얼 인터랙티브 맵</div>
        <div style="font-size:2rem;opacity:.3;margin-bottom:.6rem">🗺️</div>
        <div class="minimap-placeholder-text">${cityKey} 맵은 곧 추가됩니다.<br><span style="font-size:.7rem;opacity:.6">현재 포르투 · 교토 상세맵 추가됨</span></div>
      </div>`;

    const legendHtml = mapData.legend.map(l =>
      `<div class="legend-item"><div class="legend-dot" style="background:${l.c}"></div>${l.l}</div>`
    ).join('');

    return `
      <div id="realMapContainer" style="width:100%; height:360px; border-radius:12px; margin-bottom:1rem; border:1px solid rgba(245,240,232,0.1); z-index:1;"></div>
      <div class="minimap-legend">${legendHtml}</div>`;
  },

  senseStrip: (senses, cityName) => {
    const s = senses || {sight:`${cityName}만의 색과 빛`, sound:'골목의 소리, 사람들의 언어', smell:'현지 음식과 공기의 냄새'};
    return `<div class="sense-strip">
      <div class="sense-card"><div class="sense-icon">👁</div><div class="sense-label">시각</div><div class="sense-text">${s.sight}</div></div>
      <div class="sense-card"><div class="sense-icon">👂</div><div class="sense-label">청각</div><div class="sense-text">${s.sound}</div></div>
      <div class="sense-card"><div class="sense-icon">👃</div><div class="sense-label">후각</div><div class="sense-text">${s.smell}</div></div>
    </div>`;
  },

  budgetTab: (bpd, dur) => {
    const daily = Object.values(bpd).reduce((a, b) => a + (b || 0), 0);
    const total = daily * parseInt(dur);
    if (!daily) return '<div style="color:var(--ink-faint);font-size:.85rem;padding:1rem 0">예산 정보를 불러오는 중입니다.</div>';
    return `
      <div class="budget-row">
        ${bpd.food      ? `<div class="budget-card"><div class="budget-label">식비</div><div class="budget-amount">${(bpd.food/10000).toFixed(1)}만원</div><div class="budget-note">1인 · 하루</div></div>` : ''}
        ${bpd.transport ? `<div class="budget-card"><div class="budget-label">교통</div><div class="budget-amount">${(bpd.transport/10000).toFixed(1)}만원</div><div class="budget-note">1인 · 하루</div></div>` : ''}
        ${bpd.entrance  ? `<div class="budget-card"><div class="budget-label">입장료</div><div class="budget-amount">${(bpd.entrance/10000).toFixed(1)}만원</div><div class="budget-note">1인 · 하루</div></div>` : ''}
      </div>
      <div class="budget-total">
        <span class="budget-total-label">${dur}일 총 예상 (1인, 항공·숙박 제외)</span>
        <span class="budget-total-amount">${(total/10000).toFixed(0)}만원</span>
      </div>
      <div style="font-size:.72rem;color:var(--ink-faint);line-height:1.7;margin-top:.5rem">※ 환율·물가 변동에 따라 실제 비용은 달라질 수 있습니다. 항공권·숙박비는 별도입니다.</div>`;
  }
};

/* ════════════════════════════════════════════
   4. APP — 화면 전환 · 흐름 제어 · API
════════════════════════════════════════════ */
const App = {

  /* ── 화면 ── */
  showScreen(id, scroll = false) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active', 'active-scroll'));
    document.getElementById(id).classList.add(scroll ? 'active-scroll' : 'active');
    window.scrollTo(0, 0);
  },

  setProgress(p)   { document.getElementById('prog').style.width = p + '%'; },
  setStep(label)   { document.getElementById('stepInd').textContent = label; },

  toast(msg) {
    const t = document.getElementById('shareToast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
  },

  /* ── INTRO ── */
  renderIntro() {
    document.getElementById('sIntro').innerHTML = `<div class="intro">
      <div style="font-size:2.4rem;margin-bottom:1.1rem;opacity:.75">🧭</div>
      <div class="intro-value">취향 기반 여행 큐레이션</div>
      <h1>당신의 <em>여행 취향</em>을<br>발견해 보세요</h1>
      <p>직접 말하기 어려운 여행 취향도 있습니다.<br>몇 가지 선택만으로 당신만의 여행 DNA를 찾고,<br>그에 맞는 실제 일정까지 만들어 드립니다.</p>
      <div class="intro-steps">
        <div class="intro-step"><div class="num">STEP 01</div><div class="label">끌리는 장면</div></div>
        <div class="intro-step"><div class="num">STEP 02</div><div class="label">싫은 것 제거</div></div>
        <div class="intro-step"><div class="num">STEP 03</div><div class="label">동행 & 숙소</div></div>
      </div>
      <button class="btn btn-primary" onclick="App.startFlow()">시작하기</button>
      <div style="margin-top:.8rem;font-size:.72rem;color:var(--ink-faint)">약 3분 소요 · 결과 공유 가능</div>
    </div>`;
  },

  /* ── AB ── */
  startFlow() {
    this._setupAB();
    // sAB 컨테이너를 먼저 채운 뒤 화면 전환
    document.getElementById('sAB').innerHTML = `<div class="ab-wrap">
      <div class="ab-round" id="abRound"></div>
      <div id="abMidNudge"></div>
      <div class="ab-q"><h2 id="abQ"></h2></div>
      <div class="ab-sub">직감적으로, 빠르게 골라 주세요</div>
      <div class="ab-cards" id="abCards"></div>
    </div>`;
    this.showScreen('sAB');
    this.setStep('STEP 1/3');
    this.renderAB();
    this.setProgress(3);
  },

  _setupAB() {
    const must = CONFIG.CORE_DIMENSIONS.map(d => CONFIG.AB.find(p => p.dim === d));
    const rest = CONFIG.AB.filter(p => !CONFIG.CORE_DIMENSIONS.includes(p.dim))
                          .sort(() => Math.random() - .5);
    // Shuffle must and rest, pick 5 random elements to make it 5 rounds max
    AppState.abSubset = [...must, ...rest].sort(() => Math.random() - .5).slice(0, 5);
  },

  renderAB() {
    const { round, abSubset, choices } = AppState;
    if (round >= abSubset.length) { this.goNeg(); return; } // Skip memory step, go to neg directly
    this.setProgress(3 + (round / abSubset.length) * 37);
    const p = abSubset[round];
    document.getElementById('abRound').textContent = `${round + 1} / ${abSubset.length}`;
    
    // Changing container background slightly based on round
    document.getElementById('sAB').style.transition = 'background 0.5s ease';
    document.getElementById('sAB').style.background = `radial-gradient(circle at top left, ${p.a.c}11, transparent 60%), radial-gradient(circle at bottom right, ${p.b.c}11, transparent 60%)`;

    document.getElementById('abQ').textContent = p.q;
    const cardsHtml = ['a','b'].map(side => `
      <div class="ab-card" id="c${side.toUpperCase()}" data-side="${side}">
        <div class="ab-card-bg" style="background-image:url(${p[side].bgUrl})"></div>
        <div class="ab-content-wrap">
          <div class="ab-atmo" style="background:${p[side].c}"></div>
          <div><div class="ab-emoji">${p[side].emoji}</div><div class="ab-title">${p[side].title}</div></div>
          <div class="ab-desc">${p[side].desc}</div>
        </div>
      </div>`).join('');
    
    document.getElementById('abCards').innerHTML = cardsHtml;
    
    // Add logic for 3D tilt and Touch Swipe
    this._attachCardInteractions();
  },

  _attachCardInteractions() {
    const cards = document.querySelectorAll('.ab-card');
    cards.forEach(card => {
      // Click
      card.addEventListener('click', () => {
        if (!card.classList.contains('sel') && !card.classList.contains('notsel')) {
           this.selectAB(card.dataset.side);
        }
      });
      
      // Mouse Move (3D Tilt)
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -8;
        const rotateY = ((x - centerX) / centerX) * 8;
        
        if (!card.classList.contains('sel') && !card.classList.contains('notsel')) {
           card.style.transform = `scale(1.02) perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        }
      });

      card.addEventListener('mouseleave', () => {
        if (!card.classList.contains('sel') && !card.classList.contains('notsel')) {
           card.style.transform = `scale(1) perspective(1000px) rotateX(0deg) rotateY(0deg)`;
        }
      });
      
      // Touch (Swipe)
      let touchStartX = 0;
      let touchStartY = 0;
      card.addEventListener('touchstart', (e) => {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }, {passive:true});
      
      card.addEventListener('touchend', (e) => {
        const touchEndX = e.changedTouches[0].clientX;
        const touchEndY = e.changedTouches[0].clientY;
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        
        // Ensure its a horizontal swipe not vertical scroll
        if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY)) {
           // Provide visual feedback for swipe
           card.style.transition = 'transform 0.3s';
           if (deltaX > 0) {
              card.style.transform = `translateX(20px) rotate(3deg)`;
           } else {
              card.style.transform = `translateX(-20px) rotate(-3deg)`;
           }
           setTimeout(() => this.selectAB(card.dataset.side), 150);
        }
      });
    });
  },

  selectAB(side) {
    if(!AppState.abSubset[AppState.round]) return;
    AppState.choices[AppState.abSubset[AppState.round].dim] = side;
    
    const sel = document.getElementById(`c${side.toUpperCase()}`);
    const oth = document.getElementById(side === 'a' ? 'cB' : 'cA');
    
    if(!sel || !oth) return;

    // Reset inline styles for transform and add classes
    sel.style.transform = '';
    oth.style.transform = '';
    
    sel.classList.add('sel'); 
    oth.classList.add('notsel');
    sel.style.pointerEvents = oth.style.pointerEvents = 'none';
    
    // Add brief visual pulse to progress bar
    const pb = document.getElementById('prog');
    pb.style.boxShadow = '0 0 10px var(--terra), 0 0 20px var(--terra)';
    setTimeout(() => pb.style.boxShadow = 'none', 400);

    setTimeout(() => { AppState.round++; this.renderAB(); }, 800);
  },

  /* ── MEMORY ── */
  goMem() {
    this.goNeg(); // Safety net in case goMem is called externally
  },

  toggleEmotion(el, v) {
    el.classList.toggle('sel');
    const i = AppState.selectedEmotions.indexOf(v);
    i > -1 ? AppState.selectedEmotions.splice(i, 1) : AppState.selectedEmotions.push(v);
  },

  finMem()  { AppState.memoryText = ''; this.goNeg(); },
  skipMem() { AppState.memoryText = ''; AppState.selectedEmotions = []; this.goNeg(); },

  /* ── NEGATIVE ── */
  goNeg() {
    document.getElementById('sNeg').innerHTML = `<div class="neg-wrap">
      <h2>여행에서 <em style="color:var(--rose);font-family:'Cormorant Garamond',serif;font-style:italic">절대</em> 겪고 싶지 않은 것</h2>
      <div class="sub">해당하는 것을 모두 골라 주세요</div>
      <div class="neg-promise">✓ 선택한 항목은 일정에서 제외됩니다</div>
      <div class="neg-count" id="negCnt">0개 선택</div>
      <div class="neg-grid">${CONFIG.NEGATIVES.map((n, i) =>
        `<div class="neg-card" onclick="App.toggleNeg(this,${i})"><span class="ic">${n.i}</span><span class="tx">${n.t}</span></div>`
      ).join('')}</div>
      <button class="btn btn-primary" onclick="App.goComp()">다음으로</button>
    </div>`;
    this.showScreen('sNeg'); this.setStep('STEP 2/3'); this.setProgress(55);
  },

  toggleNeg(el, i) {
    el.classList.toggle('sel');
    const t = CONFIG.NEGATIVES[i].t;
    const idx = AppState.selectedNegatives.indexOf(t);
    idx > -1 ? AppState.selectedNegatives.splice(idx, 1) : AppState.selectedNegatives.push(t);
    document.getElementById('negCnt').textContent = AppState.selectedNegatives.length + '개 선택';
  },

  /* ── COMPANION ── */
  goComp() {
    document.getElementById('sComp').innerHTML = `<div class="comp-wrap">
      <h2>이번 여행,<br>누구와 함께인가요?</h2>
      <div class="sub">동행에 따라 일정 구성이 달라집니다</div>
      <div class="comp-grid">
        ${[['solo','🧍','혼자','내 페이스대로 완전한 자유'],['couple','👫','커플/친구','둘만의 시간, 공유할 추억'],['family','👨‍👩‍👧','가족 (어린이 포함)','아이도 즐길 수 있는 일정'],['group','👥','그룹 (3인+)','여럿이 함께 움직이는 여행']].map(([k,e,t,d]) =>
          `<div class="comp-card" onclick="App.selectComp(this,'${k}')"><div class="comp-emoji">${e}</div><div class="comp-title">${t}</div><div class="comp-desc">${d}</div></div>`
        ).join('')}
      </div>
    </div>`;
    this.showScreen('sComp'); this.setStep('STEP 3/3'); this.setProgress(65);
  },

  selectComp(el, v) {
    document.querySelectorAll('.comp-card').forEach(c => c.classList.remove('sel'));
    el.classList.add('sel');
    AppState.companion = v;
    setTimeout(() => this.goAcc(), 350);
  },

  /* ── ACCOMMODATION ── */
  goAcc() {
    AppState.accOrder = []; AppState.selectedAccChips = [];
    document.getElementById('sAcc').innerHTML = `<div class="acc-wrap">
      <h2>숙소에서 잠들기 직전,<br>가장 만족스러운 순간은?</h2>
      <div class="sub">우선순위 순서대로 1 → 2 → 3 클릭해 주세요</div>
      <div class="acc-cards">
        ${[['purity','🧼','완벽한 청결','냄새 없는 화장실, 뽀득한 시트, 먼지 한 톨 없는 바닥'],['comfort','🛏️','깊은 숙면','100수 침구에 파묻히고, 소음 없는 방, 은은한 에어컨 바람'],['sensory','✨','감각적 만족','이솝 어메니티, 디자인 가구, 창밖 야경 — 공간 자체가 경험']].map(([k,e,t,d]) =>
          `<div class="acc-card" data-cat="${k}" onclick="App.selectAcc(this,'${k}')"><div class="acc-rank"></div><div class="acc-emoji">${e}</div><div class="acc-title">${t}</div><div class="acc-desc">${d}</div></div>`
        ).join('')}
      </div>
      <div class="acc-chips-wrap" id="accChipsWrap" style="display:none">
        <div class="acc-chips-label">꼭 있었으면 하는 것은?</div>
        <div class="acc-chips" id="accChips"></div>
      </div>
      <button class="btn btn-primary" onclick="App.finAcc()">결과 보기</button>
    </div>`;
    this.showScreen('sAcc'); this.setProgress(75);
  },

  selectAcc(el, cat) {
    const { accOrder } = AppState;
    const idx = accOrder.indexOf(cat);
    idx > -1 ? accOrder.splice(idx, 1) : (accOrder.length < 3 && accOrder.push(cat));
    document.querySelectorAll('.acc-card').forEach(c => {
      const i = accOrder.indexOf(c.dataset.cat), rk = c.querySelector('.acc-rank');
      i > -1 ? (rk.textContent = i+1, c.classList.add('sel')) : (rk.textContent='', c.classList.remove('sel'));
    });
    if (accOrder.length >= 1) {
      const prim = accOrder[0], chips = CONFIG.ACC_CHIPS[prim] || [];
      document.getElementById('accChips').innerHTML = chips.map(c =>
        `<div class="acc-chip" data-cat="${prim}" onclick="App.toggleAccChip(this,'${c.t}')">${c.t}</div>`
      ).join('');
      document.getElementById('accChipsWrap').style.display = 'block';
      // restore previously selected chips
      document.querySelectorAll('.acc-chip').forEach(ch => {
        if (AppState.selectedAccChips.includes(ch.textContent)) ch.classList.add('sel');
      });
    } else {
      document.getElementById('accChipsWrap').style.display = 'none';
    }
  },

  toggleAccChip(el, t) {
    el.classList.toggle('sel');
    const i = AppState.selectedAccChips.indexOf(t);
    i > -1 ? AppState.selectedAccChips.splice(i, 1) : AppState.selectedAccChips.push(t);
  },

  finAcc() {
    this.setProgress(82);
    document.getElementById('sLoad').innerHTML = `<div class="ld-wrap">
      <div class="ld-spinner"></div>
      <div class="ld-txt" id="ldTxt">취향을 분석하고 있습니다...</div>
      <div class="ld-sub" id="ldSub">여행 DNA + 숙소 취향을 조합 중</div>
      <div class="ld-insight" id="ldInsight" style="display:none">
        <div class="ld-insight-label">흥미로운 조합 발견 ✦</div>
        <div class="ld-insight-msg" id="ldInsightMsg"></div>
      </div>
    </div>`;
    this.showScreen('sLoad'); this.setStep('');
    const ins = CONFIG.LOADING_INSIGHTS.find(i => i.cond(AppState.choices));
    if (ins) setTimeout(() => {
      document.getElementById('ldInsightMsg').textContent = ins.msg;
      document.getElementById('ldInsight').style.display = 'block';
    }, 900);
    this._analyzeProfile();
  },

  /* ── ANALYSIS API ── */
  _buildChoiceSummary() {
    return Object.entries(AppState.choices).map(([d, v]) => {
      const p = CONFIG.AB.find(x => x.dim === d);
      return p ? `${d}:"${(v==='a' ? p.a : p.b).title}"` : '';
    }).filter(Boolean).join(', ');
  },

  async _analyzeProfile() {
    const { selectedNegatives: neg, selectedEmotions: emo, memoryText, companion, accOrder, selectedAccChips } = AppState;
    const compLabel = CONFIG.COMPANION_LABELS[companion] || '미선택';
    const prompt = `여행 취향 분석가. JSON만 출력.
선택:${this._buildChoiceSummary()} / 기억:${memoryText||'없음'} / 감정:${emo.join(',')||'없음'} / 기피:${neg.join(',')||'없음'} / 동행:${compLabel} / 숙소:${accOrder.join('>')||'미선택'} / 조건:${selectedAccChips.join(',')||'없음'}
{"typeName":"","typeDesc":"2-3문장","keywords":["k1","k2","k3","k4","k5"],"dimensions":{"crowd":{"score":0-100,"leftLabel":"활기","rightLabel":"고요","desc":""},"explore":{"score":0-100,"leftLabel":"랜드마크","rightLabel":"뒷골목","desc":""},"pace":{"score":0-100,"leftLabel":"빼곡한 일정","rightLabel":"느린 여행","desc":""},"immersion":{"score":0-100,"leftLabel":"관광객","rightLabel":"현지인","desc":""}},"accProfile":{"primary":"purity|comfort|sensory","scores":{"purity":0-100,"comfort":0-100,"sensory":0-100},"chips":["조건1","조건2","조건3"]},"idealTrip":"3-4문장","hiddenTaste":"2문장","avoidReflection":"1문장","recommendCities":["도시1","도시2","도시3"]}`;
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', headers: {'Content-Type':'application/json','anthropic-version':'2023-06-01'},
        body: JSON.stringify({model:'claude-sonnet-4-20250514', max_tokens:1200, messages:[{role:'user',content:prompt}]})
      });
      const data = await res.json();
      const text = data.content.map(c => c.text || '').join('');
      AppState.currentProfile = JSON.parse(text.replace(/```json|```/g, '').trim());
      this.renderResult(AppState.currentProfile);
    } catch(e) {
      console.error(e); this._fallbackProfile();
    }
  },

  /* ── RESULT ── */
  renderResult(p) {
    this.setProgress(100);
    const { selectedNegatives: neg, companion, accOrder } = AppState;
    const acc = p.accProfile || {primary:'comfort', scores:{purity:50,comfort:50,sensory:50}, chips:[]};
    const catOrder = ['purity','comfort','sensory'].sort((a,b) => (acc.scores[b]||0) - (acc.scores[a]||0));
    const dimColors = ['#C4704B','#7A9A7E','#C4A84B','#9A7AB4'];

    document.getElementById('resContent').innerHTML = `
      <div class="res-ctx-strip">${UI.ctxStrip(p, companion, acc.primary, neg.length)}</div>
      <div class="res-header">
        <div class="res-label">Your Travel DNA</div>
        <div class="res-title">${p.typeName}</div>
        <div class="res-subtitle">${p.typeDesc}</div>
      </div>
      <div class="res-section">
        <div class="res-sec-title">취향 키워드</div>
        <div class="res-tags">${p.keywords.map(k => `<span class="res-tag">${k}</span>`).join('')}</div>
      </div>
      <div class="res-section">
        <div class="res-sec-title">취향 스펙트럼</div>
        <div class="res-dims">${Object.values(p.dimensions).map((d, i) => `
          <div class="dim-bar">
            <div class="dim-label"><span>${d.leftLabel}</span><span>${d.rightLabel}</span></div>
            <div class="dim-track"><div class="dim-fill" style="width:${d.score}%;background:${dimColors[i%4]}"></div></div>
            <div style="font-size:.68rem;color:var(--ink-faint);margin-top:.3rem">${d.desc}</div>
          </div>`).join('')}
        </div>
      </div>
      ${neg.length ? `
      <div class="res-section">
        <div class="res-sec-title">🚫 기피 항목 — 일정에서 제외됩니다</div>
        <div class="neg-reflect">
          <div class="neg-reflect-label">✕ 제외 요소</div>
          <div class="neg-reflect-chips">${neg.map(n => `<span class="neg-reflect-chip">${n}</span>`).join('')}</div>
        </div>
        ${p.avoidReflection ? `<div class="res-body" style="margin-top:.7rem;font-size:.82rem">${p.avoidReflection}</div>` : ''}
      </div>` : ''}
      <div class="res-section">
        <div class="res-sec-title">🏨 숙소 취향 프로파일</div>
        <div class="acc-res-cards">${catOrder.map((cat, i) => `
          <div class="acc-res-card ${cat}">
            <div class="arc-rank">${i===0?'★ 1순위':i===1?'2순위':'3순위'}</div>
            <div class="arc-label">${CONFIG.CAT_NAMES[cat]}</div>
            <div class="arc-bar" style="width:${acc.scores[cat]||50}%"></div>
          </div>`).join('')}
        </div>
        <div class="acc-res-chips">${(acc.chips||[]).map(c => `<span class="acc-res-chip ${acc.primary}">${c}</span>`).join('')}</div>
      </div>
      <div class="res-section"><div class="res-sec-title">이상적인 여행</div><div class="res-body">${p.idealTrip}</div></div>
      <div class="res-section"><div class="res-sec-title">숨겨진 취향 발견 💡</div><div class="res-body">${p.hiddenTaste}</div></div>
      <div class="res-section">
        <div class="res-sec-title">추천 도시</div>
        <div class="res-tags">${p.recommendCities.map(c => `<span class="res-tag">📍 ${c}</span>`).join('')}</div>
      </div>
      <div class="res-cta">
        <p>이 결과를 바탕으로 맞춤 여행 일정을 만들거나 공유해 보세요</p>
        <div class="res-cta-btns">
          <button class="btn btn-primary" onclick="App.goToPlan()">맞춤 일정 만들기 →</button>
          <button class="share-btn" onclick="App.shareResult()">🔗 결과 공유</button>
          <button class="share-btn" onclick="App.copyResult()">📋 텍스트 복사</button>
        </div>
        <div class="retry-row">
          <button class="btn btn-ghost btn-sm" onclick="App.retryFromAB()">A/B 다시 선택</button>
          <button class="btn btn-ghost btn-sm" onclick="App.retryFromNeg()">기피 항목 수정</button>
          <button class="btn btn-ghost btn-sm" onclick="location.reload()">처음부터</button>
        </div>
      </div>`;

    this.showScreen('sResult', true); this.setStep('');
    setTimeout(() => document.querySelectorAll('.dim-fill,.arc-bar').forEach(el => {
      const w = el.style.width; el.style.width = '0';
      setTimeout(() => el.style.width = w, 50);
    }), 100);
  },

  shareResult() {
    const p = AppState.currentProfile;
    const txt = `🧭 여행 취향 발견기 결과\n\n✦ ${p?.typeName||''}\n${p?.typeDesc||''}\n\n키워드: ${(p?.keywords||[]).join(' · ')}\n\n#여행취향 #TravelDNA`;
    if (navigator.share) navigator.share({title:'내 여행 DNA', text:txt}).catch(()=>{});
    else navigator.clipboard.writeText(txt).then(()=>this.toast('클립보드에 복사되었습니다 ✓')).catch(()=>this.toast('공유를 지원하지 않는 환경입니다'));
  },

  copyResult() {
    const p = AppState.currentProfile;
    const txt = `🧭 여행 취향 발견기\n\n✦ ${p?.typeName||''}\n${p?.typeDesc||''}\n\n키워드: ${(p?.keywords||[]).join(' · ')}\n이상적인 여행: ${p?.idealTrip||''}\n추천 도시: ${(p?.recommendCities||[]).join(', ')}`;
    navigator.clipboard.writeText(txt).then(()=>this.toast('결과가 클립보드에 복사되었습니다 ✓')).catch(()=>this.toast('복사에 실패했습니다'));
  },

  retryFromAB()  { AppState.reset(); this.startFlow(); },
  retryFromNeg() { AppState.resetFromNeg(); this.goNeg(); },

  _fallbackProfile() {
    const c = AppState.choices;
    const q=c.crowd==='b', l=c.local==='b', s=c.pace==='b', n=c.night==='b';
    const prim = AppState.accOrder[0] || 'comfort';
    const tns = [['고요한 골목의 관찰자','붐비는 곳을 피해 현지인의 일상 속으로 스며드는 여행자.'],
                 ['도시의 에너지 수집가','도시의 활기를 온몸으로 흡수하며 루프탑 바에서 마무리.'],
                 ['일상의 탐험가','슈퍼마켓이 더 설레는, 일상을 여행하는 여행자.'],
                 ['감각의 산책자','정해진 목적 없이 걸으며 우연한 발견에 열려 있는 여행자.']];
    const [tn, td] = q&&l&&s ? tns[0] : !q&&!s ? tns[1] : l&&s ? tns[2] : tns[3];
    this.renderResult({typeName:tn, typeDesc:td,
      keywords:[q?'고요함':'활기', l?'로컬 몰입':'랜드마크', s?'느린 여행':'알찬 일정', n?'호텔 TV':'루프탑 바', '취향 여행'],
      dimensions:{
        crowd:{score:q?78:28,leftLabel:'활기',rightLabel:'고요',desc:q?'한산한 공간에서 에너지 충전':'사람들의 에너지를 즐기는 편'},
        explore:{score:l?82:25,leftLabel:'랜드마크',rightLabel:'뒷골목',desc:l?'지도에 없는 곳에서 진짜 발견':'유명한 곳엔 이유가 있다'},
        pace:{score:s?75:22,leftLabel:'빼곡한 일정',rightLabel:'느린 여행',desc:s?'여유가 품질을 결정':'하루를 최대한 알차게'},
        immersion:{score:l?85:30,leftLabel:'관광객',rightLabel:'현지인',desc:l?'현지인의 일상이 곧 최고의 관광':'여행자로서 특별한 경험'}
      },
      accProfile:{primary:prim, scores:{purity:prim==='purity'?85:40, comfort:prim==='comfort'?85:40, sensory:prim==='sensory'?85:40}, chips:AppState.selectedAccChips.slice(0,3)},
      idealTrip: s&&q ? '한산한 유럽 소도시 카페에서 아침을 시작하고 오래된 성당의 적막 속을 걷는 일주일.' : '새로운 도시에 도착해 시장을 찾고 루프탑 바에서 야경을 보며 마무리하는 일주일.',
      hiddenTaste: n ? '호텔 방에서 현지 TV를 보는 것이 진짜 문화 체험입니다.' : '우연히 발견한 조용한 공간에서 감동을 받는 타입.',
      avoidReflection: AppState.selectedNegatives.length ? `'${AppState.selectedNegatives.slice(0,2).join("', '")}' 등을 피해 일정을 구성합니다.` : '',
      recommendCities: q&&l ? ['포르투갈 포르투','일본 교토','체코 체스키크룸로프'] : q ? ['오스트리아 빈','슬로베니아 류블랴나','벨기에 겐트'] : ['스페인 바르셀로나','태국 방콕','멕시코 멕시코시티']
    });
  },

  /* ── PLAN ── */
  goToPlan() {
    const p = AppState.currentProfile;
    const apl = CONFIG.ACC_PRIM_LABELS[AppState.accOrder[0]] || '';
    const cpl = CONFIG.COMPANION_SHORT[AppState.companion] || '';
    const ctxHtml = [
      p?.typeName ? `<span class="plan-ctx-chip dna">✦ ${p.typeName}</span>` : '',
      AppState.selectedNegatives.length ? `<span class="plan-ctx-chip avoid">✕ ${AppState.selectedNegatives.length}가지 기피</span>` : '',
      apl ? `<span class="plan-ctx-chip acc">🏨 ${apl}</span>` : '',
      cpl ? `<span class="plan-ctx-chip dna">👤 ${cpl}</span>` : ''
    ].join('');
    const cityChipsHtml = CONFIG.CITIES.map(c => 
      `<div class="city-chip ${AppState.selectedCity===c?'sel':''}" onclick="App.pickCity(this,'${c}')">${c}</div>`).join('');

    document.getElementById('sPlan').innerHTML = `<div class="plan-wrap">
      <h2>맞춤 여행 일정 만들기</h2>
      <div class="sub">취향 분석 결과를 바탕으로 나만의 일정을 생성합니다</div>
      <div class="plan-ctx">${ctxHtml}</div>
      <div class="plan-field"><label>여행지 선택</label>
        <div class="city-chips">${cityChipsHtml}</div>
        <div class="plan-or">또는 직접 입력</div>
        <input class="plan-input" type="text" id="customCity" placeholder="예: 포르투, 피렌체, 퀘벡시티..." oninput="if(this.value.trim()){document.querySelectorAll('.city-chip').forEach(x=>x.classList.remove('sel'));AppState.selectedCity='';}">
      </div>
      <div class="plan-row">
        <div class="plan-field"><label>출발일</label>
          <div class="cal-wrap" id="calWrap">
            <div class="cal-trigger" id="calTrig" onclick="App.toggleCal()">
              <span id="calDisp" class="cal-placeholder">날짜를 선택하세요</span>
              <span class="cal-arrow">▼</span>
            </div>
            <div class="cal-dd" id="calDD">
              <div class="cal-nav"><button onclick="App.calPrev()">‹</button><span class="cal-month-label" id="calMon"></span><button onclick="App.calNext()">›</button></div>
              <div class="cal-wk"><span>일</span><span>월</span><span>화</span><span>수</span><span>목</span><span>금</span><span>토</span></div>
              <div class="cal-days" id="calDays"></div>
            </div>
          </div>
        </div>
        <div class="plan-field"><label>여행 기간</label>
          <select class="plan-input" id="planDur">
            <option value="3">3일 (2박 3일)</option><option value="4">4일 (3박 4일)</option>
            <option value="5" selected>5일 (4박 5일)</option><option value="7">7일 (6박 7일)</option>
          </select>
        </div>
      </div>
      <div class="plan-field"><label>특별히 원하는 것 (선택사항)</label>
        <input class="plan-input" type="text" id="planWish" placeholder="예: 한식당 포함, 와이너리, 근교 당일치기...">
      </div>
      <div style="margin-top:1.5rem">
        <button class="btn btn-primary" onclick="App.generateItinerary()">일정 생성하기</button>
        <br><button class="btn btn-ghost" onclick="App.showScreen('sResult',true)">← 취향 결과로 돌아가기</button>
      </div>
    </div>`;

    AppState.selectedCity = '';
    const d = new Date(); d.setMonth(d.getMonth() + 1);
    AppState.calYear = d.getFullYear(); AppState.calMonth = d.getMonth();
    this.showScreen('sPlan'); this.setStep('TRIP PLANNER');
    this.renderCal();
    this._calOutsideHandlerBound = this._calOutsideHandler.bind(this);
    document.removeEventListener('click', this._calOutsideHandlerBound);
    document.addEventListener('click', this._calOutsideHandlerBound);
  },

  _calOutsideHandler(e) {
    const w = document.getElementById('calWrap');
    if (w && !w.contains(e.target)) {
      document.getElementById('calDD')?.classList.remove('show');
      document.getElementById('calTrig')?.classList.remove('open');
    }
  },

  pickCity(el, c) {
    document.querySelectorAll('.city-chip').forEach(x => x.classList.remove('sel'));
    el.classList.add('sel');
    AppState.selectedCity = c;
    document.getElementById('customCity').value = '';
  },

  toggleCal() {
    document.getElementById('calDD').classList.toggle('show');
    document.getElementById('calTrig').classList.toggle('open');
  },

  calPrev() { AppState.calMonth === 0 ? (AppState.calMonth=11, AppState.calYear--) : AppState.calMonth--; this.renderCal(); },
  calNext() { AppState.calMonth === 11 ? (AppState.calMonth=0,  AppState.calYear++) : AppState.calMonth++; this.renderCal(); },

  renderCal() {
    const { calYear: y, calMonth: m, calSelected } = AppState;
    document.getElementById('calMon').textContent = `${y}년 ${CONFIG.MONTH_NAMES[m]}`;
    const fd = new Date(y, m, 1), ld = new Date(y, m+1, 0).getDate(), sd = fd.getDay();
    const today = new Date(); today.setHours(0,0,0,0);
    const prev = new Date(y, m, 0).getDate();
    let h = '';
    for (let i = sd-1; i >= 0; i--) h += `<div class="cal-d om">${prev-i}</div>`;
    for (let d = 1; d <= ld; d++) {
      const dt = new Date(y, m, d);
      const cls = ['cal-d', dt < today ? 'past' : '', dt.getTime()===today.getTime() ? 'today' : '', calSelected&&dt.getTime()===calSelected.getTime() ? 'sel' : ''].filter(Boolean).join(' ');
      h += `<div class="${cls}" onclick="App.pickDay(${d})">${d}</div>`;
    }
    const rem = 7 - ((sd + ld) % 7);
    if (rem < 7) for (let i = 1; i <= rem; i++) h += `<div class="cal-d om">${i}</div>`;
    document.getElementById('calDays').innerHTML = h;
  },

  pickDay(d) {
    AppState.calSelected = new Date(AppState.calYear, AppState.calMonth, d);
    const dw = ['일','월','화','수','목','금','토'][AppState.calSelected.getDay()];
    document.getElementById('calDisp').textContent = `${AppState.calYear}.${String(AppState.calMonth+1).padStart(2,'0')}.${String(d).padStart(2,'0')} (${dw})`;
    document.getElementById('calDisp').classList.remove('cal-placeholder');
    this.renderCal();
    setTimeout(() => {
      document.getElementById('calDD').classList.remove('show');
      document.getElementById('calTrig').classList.remove('open');
    }, 200);
  },

  /* ── ITINERARY API ── */
  async generateItinerary() {
    const custom = document.getElementById('customCity').value.trim();
    const city = custom || AppState.selectedCity;
    if (!city) { alert('여행지를 선택하거나 입력해 주세요.'); return; }

    const { calSelected, selectedNegatives: neg, companion, accOrder } = AppState;
    const dateStr = calSelected
      ? `${calSelected.getFullYear()}-${String(calSelected.getMonth()+1).padStart(2,'0')}-${String(calSelected.getDate()).padStart(2,'0')}`
      : '미정';
    const dur      = document.getElementById('planDur').value;
    const wish     = document.getElementById('planWish').value.trim();
    const compLabel = CONFIG.COMPANION_LABELS[companion] || '미선택';
    const p        = AppState.currentProfile;

    // ── 로딩 화면 ──
    this._showItinSkeleton(city, dur);
    if (this._calOutsideHandlerBound) {
      document.removeEventListener('click', this._calOutsideHandlerBound);
      this._calOutsideHandlerBound = null;
    }
    
    // ── 도시 데이터 백그라운드 Fetch ──
    // 영어 ID 매핑용 하드코딩 (차후 서버사이드 매핑으로 발전 가능)
    const cityMap = { '포르투': 'porto', '교토': 'kyoto', '파리': 'paris', 'paris': 'paris', '런던': 'london', 'london': 'london', '뉴욕': 'new_york', 'new_york': 'new_york', '로마': 'rome', 'rome': 'rome', '바르셀로나': 'barcelona', 'barcelona': 'barcelona', '도쿄': 'tokyo', 'tokyo': 'tokyo', '방콕': 'bangkok', 'bangkok': 'bangkok', '시드니': 'sydney', 'sydney': 'sydney', '프라하': 'prague', 'prague': 'prague', '부다페스트': 'budapest', 'budapest': 'budapest', '비엔나': 'vienna', 'vienna': 'vienna', '베를린': 'berlin', 'berlin': 'berlin', '암스테르담': 'amsterdam', 'amsterdam': 'amsterdam', '리스본': 'lisbon', 'lisbon': 'lisbon', '타이베이': 'taipei', 'taipei': 'taipei', '오사카': 'osaka', 'osaka': 'osaka', '삿포로': 'sapporo', 'sapporo': 'sapporo', '싱가포르': 'singapore', 'singapore': 'singapore', '홍콩': 'hong_kong', 'hong_kong': 'hong_kong', '다낭': 'da_nang', 'da_nang': 'da_nang', '코타키나발루': 'kota_kinabalu', 'kota_kinabalu': 'kota_kinabalu', '발리': 'bali', 'bali': 'bali', '치앙마이': 'chiang_mai', 'chiang_mai': 'chiang_mai', '상하이': 'shanghai', 'shanghai': 'shanghai', '이스탄불': 'istanbul', 'istanbul': 'istanbul', '두바이': 'dubai', 'dubai': 'dubai', '시애틀': 'seattle', 'seattle': 'seattle', '샌프란시스코': 'san_francisco', 'san_francisco': 'san_francisco', '하와이': 'hawaii', 'hawaii': 'hawaii', '모로코': 'morocco', 'morocco': 'morocco' };
    const mappedId = cityMap[city.toLowerCase()] || null;
    
    if (mappedId) {
      try {
        const dRes = await fetch(`assets/cities/${mappedId}.json`);
        if(dRes.ok) AppState.cityData = await dRes.json();
        else AppState.cityData = null;
      } catch(e) { AppState.cityData = null; }
    } else {
      AppState.cityData = null;
    }

    // ── 경량화된 프롬프트 (옵션 C) ──
    // senseNote·bestTime·transitReason·altSpot 필드 제거 → note 1필드로 통합
    // 출력 토큰 ~35% 절감
    const prompt = `여행 일정 전문가. 실제 존재 장소(상호명·가격 포함)로 JSON만 출력. 불필요한 설명 없이 JSON만.
여행자:${p?.typeName||''} / 기피(반드시 제외):${neg.join(',')||'없음'} / 동행:${compLabel} / 숙소:${accOrder.join('>')||'미선택'}
여행지:${city} / 출발일:${dateStr} / 기간:${dur}일 / 요청:${wish||'없음'}
spot의 note에 주소·가격·팁·감각묘사를 모두 포함. tags는 ["혼잡도 낮음","로컬 추천","기피 요소 없음"] 중 해당하는 것만.
{"destination":"","title":"","summary":"","palette":["#hex1","#hex2","#hex3"],"cityTagline":"한 문장","heroEmoji":"이모지","budgetPerDay":{"food":0,"transport":0,"entrance":0},"days":[{"day":1,"title":"","desc":"","spots":[{"time":"09:00","name":"","note":"주소·가격·팁·감각묘사","sense":"감각 1문장","tags":[],"cost":0}]}],"tips":""}`;

    try {
      // ── 스트리밍 호출 (옵션 A) ──
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'anthropic-version': '2023-06-01'},
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2200,   // 경량화로 상한 하향
          stream: true,
          messages: [{role:'user', content: prompt}]
        })
      });

      if (!res.ok) throw new Error(`API ${res.status}`);

      let buffer = '';
      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      // SSE 파싱 루프
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, {stream: true});
        for (const line of chunk.split('\n')) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6).trim();
          if (data === '[DONE]') break;
          try {
            const evt = JSON.parse(data);
            if (evt.type === 'content_block_delta' && evt.delta?.type === 'text_delta') {
              buffer += evt.delta.text;
              this._updateStreamProgress(buffer); // 실시간 진행 표시
            }
          } catch { /* 불완전 JSON 청크 무시 */ }
        }
      }

      // 완성된 JSON 파싱 및 렌더링
      const clean = buffer.replace(/```json|```/g, '').trim();
      this.renderItinerary(JSON.parse(clean), city, dur, dateStr);

    } catch(e) {
      console.error(e);
      this._fallbackItinerary(city, dur, dateStr);
    }
  },

  // 스트리밍 중 Day 개수를 감지해 로딩 메시지를 업데이트
  _updateStreamProgress(buf) {
    const days = (buf.match(/"day"\s*:/g) || []).length;
    const sub = document.getElementById('ldSub');
    if (sub && days > 0) sub.textContent = `Day ${days} 생성 중...`;
  },

  // 스켈레톤 로딩 화면 (스트리밍 시작 전 즉시 표시)
  _showItinSkeleton(city, dur) {
    document.getElementById('sLoad').innerHTML = `<div class="ld-wrap">
      <div class="ld-spinner"></div>
      <div class="ld-txt">${city} 일정을 만들고 있습니다</div>
      <div class="ld-sub" id="ldSub">연결 중...</div>
      <div class="ld-insight" style="display:block;margin-top:1.6rem">
        <div class="ld-insight-label">생성 현황 ✦</div>
        <div class="ld-insight-msg" id="ldProgress">
          ${Array.from({length: parseInt(dur)}, (_, i) =>
            `<span id="day-prog-${i+1}" style="display:inline-block;margin:.15rem .3rem;font-size:.72rem;
              padding:.2rem .6rem;border-radius:10px;background:rgba(245,240,232,.04);
              border:1px solid rgba(245,240,232,.08);color:var(--ink-faint)">
              Day ${i+1}
            </span>`).join('')}
        </div>
      </div>
    </div>`;
    this.showScreen('sLoad');

    // Day 칩 순차 점등 애니메이션 (시각적 피드백)
    let lit = 0;
    this._skelTimer = setInterval(() => {
      const el = document.getElementById(`day-prog-${++lit}`);
      if (el) {
        el.style.background = 'rgba(196,112,75,.12)';
        el.style.borderColor = 'rgba(196,112,75,.35)';
        el.style.color = 'var(--terra-light)';
      }
      if (lit >= parseInt(dur)) clearInterval(this._skelTimer);
    }, 900);
  },

  /* ── RENDER ITINERARY ── */
  renderItinerary(it, city, dur, dateStr) {
    const { companion, accOrder, selectedNegatives: neg, currentProfile: p } = AppState;
    const cpl = {solo:'혼자',couple:'커플/친구',family:'가족',group:'그룹'}[companion] || '';
    const apl = CONFIG.ACC_PRIM_LABELS[accOrder[0]] || '';
    const palette = it.palette || ['#C4704B','#6B8BA4','#C4A84B'];

    // JSON cityData 연동 
    const cd = AppState.cityData;
    const month = dateStr !== '미정' ? new Date(dateStr).getMonth()+1 : null;
    const seasonKey = month ? (month>=3&&month<=5?'spring':month>=6&&month<=8?'summer':month>=9&&month<=11?'autumn':'winter') : null;
    const seasonLabel = {spring:'봄 (3~5월)',summer:'여름 (6~8월)',autumn:'가을 (9~11월)',winter:'겨울 (12~2월)'}[seasonKey] || '';
    
    let seasonInfo = null, senseInfo = null, mapData = null;
    if (cd) {
      if (seasonKey && cd.seasons && cd.seasons[seasonKey]) seasonInfo = cd.seasons[seasonKey];
      if (cd.senses) senseInfo = cd.senses;
      if (cd.map) mapData = cd.map;
    }

    document.getElementById('itinContent').innerHTML = `
      <div class="city-hero" style="background:linear-gradient(135deg,${palette[0]}22 0%,${palette[1]}22 100%);border:1px solid ${palette[0]}30">
        <div class="city-hero-eyebrow" style="color:${palette[0]}">✦ ${p?.typeName||'여행자'}의 맞춤 일정</div>
        <div class="city-hero-name">${it.heroEmoji||'🗺️'} ${it.destination||city}</div>
        <div class="city-hero-tagline">${it.cityTagline||it.summary||''}</div>
        <div class="city-hero-meta">
          ${cpl ? `<span class="city-meta-chip">👤 ${cpl}</span>` : ''}
          ${apl ? `<span class="city-meta-chip">🏨 ${apl}</span>` : ''}
          ${neg.length ? `<span class="city-meta-chip">✕ ${neg.length}가지 기피 제외</span>` : ''}
          ${dateStr !== '미정' ? `<span class="city-meta-chip">📅 ${dateStr}</span>` : ''}
          <span class="city-meta-chip">⏱ ${dur}일</span>
        </div>
      </div>
      <div class="itin-ctx">
        ${p?.typeName ? `<span class="itin-ctx-chip dna">✦ ${p.typeName}</span>` : ''}
        ${neg.length  ? `<span class="itin-ctx-chip avoid">✕ ${neg.length}가지 기피 제외</span>` : ''}
        ${apl ? `<span class="itin-ctx-chip acc">🏨 ${apl}</span>` : ''}
        ${cpl ? `<span class="itin-ctx-chip comp">👤 ${cpl}</span>` : ''}
      </div>
      <div class="itin-tabs">
        <button class="itin-tab active" onclick="App.switchTab('schedule',this)">📅 일정</button>
        <button class="itin-tab" onclick="App.switchTab('cityinfo',this)">🏙 도시 정보</button>
        <button class="itin-tab" onclick="App.switchTab('budget',this)">💰 예산</button>
      </div>

      <div class="tab-panel active" id="tab-schedule">
        ${(it.days||[]).map(UI.daySection).join('')}
        ${it.tips ? `<div class="itin-tips"><h3>실용 팁</h3><p>${it.tips.replace(/\n/g,'<br>')}</p></div>` : ''}
      </div>

      <div class="tab-panel" id="tab-cityinfo">
        ${seasonInfo ? `<div class="season-card"><div class="season-icon">${seasonInfo.icon}</div><div class="season-body"><div class="season-label">${seasonLabel} 여행</div><div class="season-text">${seasonInfo.text}</div></div></div>` : ''}
        ${UI.senseStrip(senseInfo, it.destination||city)}
        ${UI.minimap(mapData, city)}
        <div style="font-size:.82rem;color:rgba(245,240,232,.6);line-height:1.9">${it.summary||''}</div>
      </div>

      <div class="tab-panel" id="tab-budget">
        ${UI.budgetTab(it.budgetPerDay||{}, dur)}
      </div>

      <div class="itin-footer">
        <button class="btn btn-ghost" onclick="App.goToPlan()">← 다른 도시로</button>
        <br><button class="btn btn-ghost" onclick="location.reload()" style="margin-top:.4rem">처음부터 다시</button>
      </div>`;

    this.showScreen('sItin', true); this.setStep('');
    if (mapData) {
      setTimeout(() => this._initRealMap(mapData), 80);
    }
  },

  _initRealMap(mapData) {
    const container = document.getElementById('realMapContainer');
    if (!container || !mapData) return;
    
    // Check if map already initialized
    if (this._realMap) {
      this._realMap.remove();
    }
    
    // Use Light theme tile layer
    const tileLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 19
    });
    
    this._realMap = L.map('realMapContainer').setView([mapData.lat, mapData.lng], mapData.zoom || 13);
    tileLayer.addTo(this._realMap);
    
    mapData.pins.forEach(p => {
      // Create custom divIcon resembling the previous pin style
      const icon = L.divIcon({
        className: 'custom-map-pin',
        html: `<div style="background:${p.color}; width:20px; height:20px; border-radius:50%; color:white; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:bold; box-shadow:0 0 10px ${p.color}88; border:2px solid white;">${p.num}</div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });
      L.marker([p.lat, p.lng], { icon })
        .addTo(this._realMap)
        .bindPopup(`<strong>${p.name}</strong><br><span style="font-size:0.8rem;color:#666">${p.time}</span><br><p style="margin:5px 0 0;font-size:0.85rem;color:#444">${p.note}</p>`);
    });
    
    setTimeout(() => {
      if(this._realMap) this._realMap.invalidateSize();
    }, 150);
  },

  switchTab(name, el) {
    document.querySelectorAll('.itin-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('tab-'+name).classList.add('active');
    if (name === 'cityinfo' && this._realMap) {
      setTimeout(() => this._realMap.invalidateSize(), 50);
    }
  },

  /* ── FALLBACK ITINERARY ── */
  _fallbackItinerary(city, dur, dateStr) {
    const n = parseInt(dur), days = [];
    const makeSpot = (time, name, note, sense, tags, cost=0) =>
      ({time, name, note, senseNote:sense, matchTags:tags, bestTime:'', transitReason:'', altSpot:'', cost});
    for (let i = 1; i <= n; i++) {
      let spots = [];
      if (i === 1) spots = [makeSpot('15:00','체크인 & 주변 산책','도보 10분 반경 파악','처음 맡는 도시의 공기. 설렘과 낯섦이 섞인 냄새.',['혼잡도 낮음'],0),makeSpot('17:00','스페셜티 커피','Google Maps 평점 4.5+','핸드드립 향이 골목 밖까지.',['로컬 추천'],8000),makeSpot('19:00','현지 저녁 식사','현지어 리뷰 많은 곳','',['로컬 추천'],20000)];
      else if (i === n) spots = [makeSpot('09:00','마지막 산책','좋았던 골목 재방문','이미 익숙해진 돌길.',['혼잡도 낮음'],0),makeSpot('12:00','체크아웃','이동 시간 넉넉히','',[], 0)];
      else spots = [makeSpot('08:30','주요 명소','아침 일찍 = 한산','',['이른 아침 추천'],10000),makeSpot('11:00','로컬 마켓','식재료 구경이 도시를 이해하는 가장 빠른 방법','향신료와 생선 냄새가 뒤섞인 공기.',['로컬 추천'],15000),makeSpot('14:00','오후 카페','현지인 카페에서 휴식','',['혼잡도 낮음'],8000),makeSpot('19:00','저녁 식사','당일 예약','',['기피 요소 없음'],25000)];
      days.push({day:i, title:i===1?'도착':i===n?'출발':'탐방', desc:'', spots});
    }
    this.renderItinerary({
      destination:city, title:`${city} ${dur}일`,
      summary:`${AppState.currentProfile?.typeName||'여행자'}의 취향에 맞춘 일정입니다.`,
      palette:['#C4704B','#6B8BA4','#7A9A7E'], cityTagline:`${city}에서 보내는 ${dur}일간의 취향 여행`, heroEmoji:'🗺️',
      budgetPerDay:{food:30000,transport:15000,entrance:10000,etc:10000}, days,
      tips:'숙소: Booking.com 부티크 호텔 필터링.\n현지 슈퍼마켓 과자 코너 필수 방문.\nGoogle Maps 현지어 리뷰 높은 식당 = 진짜 맛집.'
    }, city, dur, dateStr);
  },

  /* ── INIT ── */
  init() {
    this.renderIntro();
  }
};

/* 전역 진입점 */
window.onload = () => App.init();
